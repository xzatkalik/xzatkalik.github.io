# Subory slovnika na importovanie do Latex editora
Original stiahnuty z Openffice stranky

# Texstudio
oba subory treba prekopirovat do adresara
/usr/share/texstudio
